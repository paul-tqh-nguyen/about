For the paper:
Image Perforation: Automatically Accelerating Image Pipelines by Intelligently Skipping Samples
Liming Lou, Paul Nguyen, Jason Lawrence, Connelly Barnes
ACM Transactions on Graphics 2016 (to appear at ACM SIGGRAPH 2016)

This directory contains 114 testing images in PNG format,
with each data.txt file containing the information about
the original source image and its license.
